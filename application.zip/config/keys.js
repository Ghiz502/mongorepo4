module.exports={
    MongoURI: 'mongodb+srv://ghizlane2:azerty@cluster0-v89gm.mongodb.net/test?retryWrites=true&w=majority'
}